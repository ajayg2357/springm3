package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import bean.Invoice;
import exception.ProductException;
import service.InvoiceService;

@RestController
public class Controller {

	@Autowired
	InvoiceService service;
	
	
	@RequestMapping(value = "/product", method = RequestMethod.POST)
	public List<Invoice> createProduct(@RequestBody Invoice prod) throws ProductException {
		return service.createProduct(prod);
	
	}
	
	// update product by id
		@PutMapping("/product/{id}")
		public List<Invoice> updateProduct(@PathVariable int id, @RequestBody Invoice prod)
				throws ProductException {
			return service.updateProduct(id, prod);
		}	
		
		// get all products
		@RequestMapping(value="/thunga",method = RequestMethod.GET)
		public List<Invoice> getProduct() throws ProductException {
			return service.getAllProducts();
		}
		
		// delete product by id
		@DeleteMapping("/product/{id}")
		public ResponseEntity<String> deleteProduct(@PathVariable int id) throws ProductException {
			service.deleteProduct(id);
			return new ResponseEntity<String>("Product with id " + id + " deleted", HttpStatus.OK);
		}
		
		// get product by id
		@RequestMapping("/product/{id}")
		public Invoice geProductById(@PathVariable int id) throws ProductException {

			return service.getProductById(id);
		}
}
