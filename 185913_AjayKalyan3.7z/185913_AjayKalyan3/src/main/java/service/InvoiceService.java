package service;

import java.util.List;

import bean.Invoice;
import exception.ProductException;

public interface InvoiceService {
	
	public List<Invoice> createProduct(Invoice prod) throws ProductException;
	
	public List<Invoice> updateProduct(int id, Invoice prod) throws ProductException;
	
	public List<Invoice> getAllProducts() throws ProductException;

	public void deleteProduct(int id) throws ProductException;

	public Invoice getProductById(int id) throws ProductException;
}
