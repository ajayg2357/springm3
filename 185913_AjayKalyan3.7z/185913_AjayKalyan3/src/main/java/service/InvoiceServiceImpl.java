package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bean.Invoice;
import dao.InvoiceDao;
import exception.ProductException;

@Service
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	InvoiceDao dao;
	
	Invoice voice=new Invoice();

	@Override
	public List<Invoice> createProduct(Invoice prod) throws ProductException {
		// TODO Auto-generated method stub
		try {
			double cgst=(voice.getAmount()*voice.getDistance()*5)*(0.035);
			double sgst = cgst;
			voice.setCgst(cgst);
			voice.setSgst(sgst);
			dao.save(prod);
			return dao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public List<Invoice> updateProduct(int id, Invoice prod) throws ProductException {
		try {
			Optional<Invoice> optional = dao.findById(id);
			if (optional.isPresent()) {
				Invoice product = optional.get();
				product.setWeight(prod.getWeight());
				product.setDistance(prod.getDistance());
				product.setAmount(prod.getAmount());

				dao.save(product);
				return getAllProducts();
			} else {
				throw new ProductException("Customer with Id" + id + " does not exist");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());

		}
	}

	@Override
	public List<Invoice> getAllProducts() throws ProductException {
		try {
			return dao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public void deleteProduct(int id) throws ProductException {
		try {
			dao.deleteById(id);
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public Invoice getProductById(int id) throws ProductException {
		try {
			return dao.findById(id).get();
		} catch (Exception ex) {
			throw new ProductException(ex.getMessage());
		}
	}

}
